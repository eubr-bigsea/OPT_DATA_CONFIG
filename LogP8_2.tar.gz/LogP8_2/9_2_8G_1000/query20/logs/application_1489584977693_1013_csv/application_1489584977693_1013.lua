-- DAG definition: it is encoded as an array of stages.
Stages = {{ name="J1S1", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query20/logs/application_1489584977693_1013_csv/J1S1.txt")}}, pre={}, post={"J2S2","J2S3"}},{ name="J0S0", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query20/logs/application_1489584977693_1013_csv/J0S0.txt")}}, pre={}, post={"J2S2","J2S3"}},{ name="J2S3", tasks="3000", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query20/logs/application_1489584977693_1013_csv/J2S3.txt")}}, pre={"J1S1","J0S0"}, post={"J2S4"}},{ name="J2S2", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query20/logs/application_1489584977693_1013_csv/J2S2.txt")}}, pre={"J1S1","J0S0"}, post={"J2S4"}},{ name="J2S5", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query20/logs/application_1489584977693_1013_csv/J2S5.txt")}}, pre={"J2S4"}, post={"J2S6"}},{ name="J2S4", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query20/logs/application_1489584977693_1013_csv/J2S4.txt")}}, pre={"J2S2","J2S3"}, post={"J2S5"}},{ name="J2S6", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query20/logs/application_1489584977693_1013_csv/J2S6.txt")}}, pre={"J2S5"}, post={}}};

-- Number of computation nodes in the system
Nodes = 18;

-- Number of users accessing the system
Users = 1;

-- Distribution of the think time for the users
UThinkTimeDistr = {type = "exp", params = {rate = 0.001}};

-- Total number of jobs to simulate
maxJobs = 1000;

-- Coefficient for the Confidence Intervals
confIntCoeff = 1.96;
