-- DAG definition: it is encoded as an array of stages.
Stages = {{ name="J1S1", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query52/logs/application_1489584977693_1020_csv/J1S1.txt")}}, pre={"J0S0"}, post={"J1S3"}},{ name="J0S0", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query52/logs/application_1489584977693_1020_csv/J0S0.txt")}}, pre={}, post={"J1S1","J1S2"}},{ name="J1S3", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query52/logs/application_1489584977693_1020_csv/J1S3.txt")}}, pre={"J1S1","J1S2"}, post={"J1S4"}},{ name="J1S2", tasks="3958", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query52/logs/application_1489584977693_1020_csv/J1S2.txt")}}, pre={"J0S0"}, post={"J1S3"}},{ name="J1S4", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/9_2_8G_1000/query52/logs/application_1489584977693_1020_csv/J1S4.txt")}}, pre={"J1S3"}, post={}}};

-- Number of computation nodes in the system
Nodes = 18;

-- Number of users accessing the system
Users = 1;

-- Distribution of the think time for the users
UThinkTimeDistr = {type = "exp", params = {rate = 0.001}};

-- Total number of jobs to simulate
maxJobs = 1000;

-- Coefficient for the Confidence Intervals
confIntCoeff = 1.96;
