-- DAG definition: it is encoded as an array of stages.
Stages = {{ name="J1S1", tasks="2", distr={type="empirical", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/12_2_8G_500/Q52/empirical/J1S1.txt")}}, pre={}, post={"J2S2"}},{ name="J0S0", tasks="2", distr={type="empirical", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/12_2_8G_500/Q52/empirical/J0S0.txt")}}, pre={}, post={"J2S2"}},{ name="J2S3", tasks="200", distr={type="empirical", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/12_2_8G_500/Q52/empirical/J2S3.txt")}}, pre={"J2S2"}, post={}},{ name="J2S2", tasks="500", distr={type="empirical", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/12_2_8G_500/Q52/empirical/J2S2.txt")}}, pre={"J1S1","J0S0"}, post={"J2S3"}}};

-- Number of computation nodes in the system
Nodes = 24;

-- Number of users accessing the system
Users = 1;

-- Distribution of the think time for the users
UThinkTimeDistr = {type = "exp", params = {rate = 0.001}};

-- Total number of jobs to simulate
maxJobs = 1000;

-- Coefficient for the Confidence Intervals
confIntCoeff = 1.96;
