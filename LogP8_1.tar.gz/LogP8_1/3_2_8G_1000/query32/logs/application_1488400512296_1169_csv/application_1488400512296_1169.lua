-- DAG definition: it is encoded as an array of stages.
Stages = {{ name="J1S1", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J1S1.txt")}}, pre={}, post={"J2S5","J2S2","J2S4"}},{ name="J0S0", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J0S0.txt")}}, pre={}, post={"J2S5","J2S2","J2S4"}},{ name="J2S3", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J2S3.txt")}}, pre={"J2S2"}, post={"J2S7"}},{ name="J2S2", tasks="3000", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J2S2.txt")}}, pre={"J1S1","J0S0"}, post={"J2S3"}},{ name="J2S5", tasks="3000", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J2S5.txt")}}, pre={"J1S1","J0S0"}, post={"J2S6"}},{ name="J2S4", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J2S4.txt")}}, pre={"J1S1","J0S0"}, post={"J2S6"}},{ name="J2S7", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J2S7.txt")}}, pre={"J2S3","J2S6"}, post={"J2S8"}},{ name="J2S6", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J2S6.txt")}}, pre={"J2S4","J2S5"}, post={"J2S7"}},{ name="J2S8", tasks="1", distr={type="replay", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query32/logs/application_1488400512296_1169_csv/J2S8.txt")}}, pre={"J2S7"}, post={}}};

-- Number of computation nodes in the system
Nodes = 6;

-- Number of users accessing the system
Users = 1;

-- Distribution of the think time for the users
UThinkTimeDistr = {type = "exp", params = {rate = 0.001}};

-- Total number of jobs to simulate
maxJobs = 1000;

-- Coefficient for the Confidence Intervals
confIntCoeff = 1.96;
