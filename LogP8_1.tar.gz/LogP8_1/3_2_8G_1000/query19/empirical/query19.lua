-- DAG definition: it is encoded as an array of stages.
Stages = {{ name="J3S10", tasks="200", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J3S10.txt")}}, pre={"J3S9"}, post={"J4S18"}},{ name="J4S19", tasks="1", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J4S19.txt")}}, pre={"J4S18"}, post={"J5S28"}},{ name="J4S18", tasks="200", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J4S18.txt")}}, pre={"J3S10"}, post={"J4S19"}},{ name="J5S28", tasks="2", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J5S28.txt")}}, pre={"J4S19"}, post={}},{ name="J1S1", tasks="2", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J1S1.txt")}}, pre={}, post={"J3S5","J3S6","J3S3","J3S4"}},{ name="J0S0", tasks="2", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J0S0.txt")}}, pre={}, post={"J3S5","J3S6","J3S3","J3S4"}},{ name="J3S3", tasks="1000", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J3S3.txt")}}, pre={"J1S1","J0S0","J2S2"}, post={"J3S9"}},{ name="J2S2", tasks="2", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J2S2.txt")}}, pre={}, post={"J3S5","J3S6","J3S3","J3S4"}},{ name="J3S5", tasks="2", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J3S5.txt")}}, pre={"J1S1","J0S0","J2S2"}, post={"J3S7"}},{ name="J3S4", tasks="1000", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J3S4.txt")}}, pre={"J1S1","J0S0","J2S2"}, post={"J3S8"}},{ name="J3S7", tasks="200", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J3S7.txt")}}, pre={"J3S5","J3S6"}, post={"J3S8"}},{ name="J3S6", tasks="3958", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J3S6.txt")}}, pre={"J1S1","J0S0","J2S2"}, post={"J3S7"}},{ name="J3S9", tasks="200", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J3S9.txt")}}, pre={"J3S3","J3S8"}, post={"J3S10"}},{ name="J3S8", tasks="200", distr={type="empirical", params={samples=solver.fileToArray("/home/work/Downloads/LogP8/3_2_8G_1000/query19/empirical/J3S8.txt")}}, pre={"J3S4","J3S7"}, post={"J3S9"}}};

-- Number of computation nodes in the system
Nodes = 6;

-- Number of users accessing the system
Users = 1;

-- Distribution of the think time for the users
UThinkTimeDistr = {type = "exp", params = {rate = 0.001}};

-- Total number of jobs to simulate
maxJobs = 1000;

-- Coefficient for the Confidence Intervals
confIntCoeff = 1.96;
