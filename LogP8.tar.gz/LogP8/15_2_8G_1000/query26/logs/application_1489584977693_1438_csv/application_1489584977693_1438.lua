-- DAG definition: it is encoded as an array of stages.
Stages = {{ name="J1S1", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J1S1.txt")}}, pre={}, post={"J4S5","J4S6","J4S4"}},{ name="J0S0", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J0S0.txt")}}, pre={}, post={}},{ name="J3S3", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J3S3.txt")}}, pre={}, post={"J4S5","J4S6","J4S4"}},{ name="J2S2", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J2S2.txt")}}, pre={}, post={"J4S5","J4S6","J4S4"}},{ name="J4S5", tasks="1000", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J4S5.txt")}}, pre={"J1S1","J3S3","J2S2"}, post={"J4S7"}},{ name="J4S4", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J4S4.txt")}}, pre={"J1S1","J3S3","J2S2"}, post={"J4S8"}},{ name="J4S7", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J4S7.txt")}}, pre={"J4S5","J4S6"}, post={"J4S8"}},{ name="J4S6", tasks="3000", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J4S6.txt")}}, pre={"J1S1","J3S3","J2S2"}, post={"J4S7"}},{ name="J4S9", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J4S9.txt")}}, pre={"J4S8"}, post={}},{ name="J4S8", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/LogP8/15_2_8G_1000/query26/logs/application_1489584977693_1438_csv/J4S8.txt")}}, pre={"J4S4","J4S7"}, post={"J4S9"}}};

-- Number of computation nodes in the system
Nodes = 30;

-- Number of users accessing the system
Users = 1;

-- Distribution of the think time for the users
UThinkTimeDistr = {type = "exp", params = {rate = 0.001}};

-- Total number of jobs to simulate
maxJobs = 1000;

-- Coefficient for the Confidence Intervals
confIntCoeff = 1.96;
